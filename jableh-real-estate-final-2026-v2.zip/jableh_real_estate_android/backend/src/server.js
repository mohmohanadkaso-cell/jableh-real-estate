import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import Database from 'better-sqlite3';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';

const __dirname=path.dirname(fileURLToPath(import.meta.url));
const dataDir=path.join(__dirname,'../data');
fs.mkdirSync(dataDir,{recursive:true});
const db=new Database(path.join(dataDir,'jableh.db'));
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS properties(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,type TEXT NOT NULL,deal TEXT NOT NULL,location TEXT NOT NULL,
 price TEXT,area TEXT,rooms INTEGER DEFAULT 0,status TEXT NOT NULL,
 publication_status TEXT NOT NULL DEFAULT 'published',description TEXT DEFAULT '',
 views INTEGER NOT NULL DEFAULT 0,favorites_count INTEGER NOT NULL DEFAULT 0,contacts INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL,updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS requests(
 id INTEGER PRIMARY KEY AUTOINCREMENT,code TEXT UNIQUE NOT NULL,type TEXT NOT NULL,status TEXT NOT NULL,
 user_name TEXT,user_phone TEXT,payload TEXT NOT NULL,created_at TEXT NOT NULL,updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS admin_users(id INTEGER PRIMARY KEY AUTOINCREMENT,email TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL);
`);
const now=()=>new Date().toISOString();
const allowedLocations=new Set(['كل جبلة','مدينة جبلة','ريف جبلة','المنطقة المحددة على الخريطة']);
const allowedStatuses=new Set(['available','for_rent','paused','closed_sold','closed_rented']);
const allowedRequestStatuses=new Set(['new','in_progress','waiting_info','completed','closed']);
const env=process.env;
const production=env.NODE_ENV==='production';
const secret=env.JWT_SECRET||(!production?'dev-only-change-me':null);
if(!secret) throw new Error('JWT_SECRET is required in production');
const adminEmail=env.ADMIN_EMAIL||(!production?'admin@jableh.local':null);
const adminPass=env.ADMIN_PASSWORD||(!production?'Jableh@2026':null);
if(!adminEmail||!adminPass) throw new Error('ADMIN_EMAIL and ADMIN_PASSWORD are required in production');
if(db.prepare('SELECT COUNT(*) c FROM properties').get().c===0){
 const ins=db.prepare(`INSERT INTO properties(name,type,deal,location,price,area,rooms,status,publication_status,description,views,favorites_count,contacts,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
 for(const p of [
  ['منزل عائلي مميز','منزل','للبيع','مدينة جبلة','250,000 $','180 م²',4,'available','published','منزل ضمن نطاق مدينة جبلة.',124,18,6],
  ['شقة سكنية','شقة','للإيجار','مدينة جبلة','1,500,000 ل.س','120 م²',3,'for_rent','published','شقة سكنية للإيجار.',96,12,4],
  ['أرض مناسبة للبناء','أرض','للبيع','ريف جبلة','85,000 $','600 م²',0,'available','published','أرض ضمن ريف جبلة.',71,9,3],
  ['منزل تم بيعه','منزل','للبيع','مدينة جبلة','—','150 م²',3,'closed_sold','published','عقار مغلق تاريخيًا بعد البيع.',210,24,10]
 ]) ins.run(...p,now(),now());
}
if(db.prepare('SELECT COUNT(*) c FROM admin_users').get().c===0) db.prepare('INSERT INTO admin_users(email,password_hash) VALUES(?,?)').run(adminEmail,bcrypt.hashSync(adminPass,12));

const app=express();
app.disable('x-powered-by');
app.use(helmet());
app.use(cors({origin:env.CORS_ORIGIN||'*',methods:['GET','POST','PATCH','OPTIONS'],allowedHeaders:['Content-Type','Authorization']}));
app.use(express.json({limit:'2mb'}));
app.use(rateLimit({windowMs:15*60*1000,max:300,standardHeaders:true,legacyHeaders:false}));
function auth(req,res,next){const h=req.headers.authorization||'';if(!h.startsWith('Bearer '))return res.status(401).json({error:'Unauthorized'});try{req.admin=jwt.verify(h.slice(7),secret);next()}catch{return res.status(401).json({error:'Unauthorized'})}}
function publicProperty(p){return p}
function requestCode(type){const prefix={owner:'OR',buyer:'BR',viewing:'VIS',contact:'CON'}[type]||'REQ';return `JB-${prefix}-${String(Date.now()).slice(-8)}`}
function validatePropertyInput(body){if(!body.name||!body.type||!body.deal||!body.location)return 'name,type,deal,location are required';if(!allowedLocations.has(body.location))return 'Invalid location';if(!allowedStatuses.has(body.status||'available'))return 'Invalid status';return null}

app.get('/health',(req,res)=>res.json({ok:true,service:'jableh-real-estate-api',time:now(),version:'1.1.0'}));
app.post('/api/admin/login',(req,res)=>{const {email,password}=req.body||{};const u=db.prepare('SELECT * FROM admin_users WHERE email=?').get(email);if(!u||!bcrypt.compareSync(password||'',u.password_hash))return res.status(401).json({error:'بيانات تسجيل الدخول غير صحيحة'});res.json({token:jwt.sign({id:u.id,email:u.email,role:'admin'},secret,{expiresIn:'8h'})})});
app.get('/api/properties',(req,res)=>{const {deal,location,status}=req.query;let q='SELECT * FROM properties WHERE publication_status=\'published\'';const a=[];if(deal&&deal!=='الكل'){q+=' AND deal=?';a.push(deal)}if(location&&location!=='كل جبلة'){q+=' AND location=?';a.push(location)}if(status){q+=' AND status=?';a.push(status)}q+=' ORDER BY id DESC';res.json(db.prepare(q).all(...a).map(publicProperty))});
app.get('/api/properties/:id',(req,res)=>{const p=db.prepare('SELECT * FROM properties WHERE id=? AND publication_status=\'published\'').get(req.params.id);if(!p)return res.status(404).json({error:'Not found'});db.prepare('UPDATE properties SET views=views+1,updated_at=? WHERE id=?').run(now(),req.params.id);res.json(publicProperty({...p,views:p.views+1}))});
app.post('/api/requests',(req,res)=>{const {type,user_name='',user_phone='',payload={}}=req.body||{};if(!['owner','buyer','viewing','contact'].includes(type))return res.status(400).json({error:'Invalid request type'});const code=requestCode(type),t=now();db.prepare(`INSERT INTO requests(code,type,status,user_name,user_phone,payload,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)`).run(code,type,'new',String(user_name).slice(0,120),String(user_phone).slice(0,60),JSON.stringify(payload).slice(0,100000),t,t);if((type==='contact'||type==='viewing')&&payload.property_id){db.prepare('UPDATE properties SET contacts=contacts+1,updated_at=? WHERE id=?').run(t,payload.property_id)}res.status(201).json({code,status:'new'});});
app.get('/api/admin/properties',auth,(req,res)=>res.json(db.prepare('SELECT * FROM properties ORDER BY id DESC').all()));
app.post('/api/admin/properties',auth,(req,res)=>{const b=req.body||{},err=validatePropertyInput(b);if(err)return res.status(400).json({error:err});const t=now();const r=db.prepare(`INSERT INTO properties(name,type,deal,location,price,area,rooms,status,publication_status,description,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`).run(b.name,b.type,b.deal,b.location,b.price||'',b.area||'',Number(b.rooms||0),b.status||'available',b.publication_status||'draft',b.description||'',t,t);res.status(201).json(db.prepare('SELECT * FROM properties WHERE id=?').get(r.lastInsertRowid));});
app.patch('/api/admin/properties/:id',auth,(req,res)=>{const b=req.body||{};const p=db.prepare('SELECT * FROM properties WHERE id=?').get(req.params.id);if(!p)return res.status(404).json({error:'Not found'});if(b.location&&!allowedLocations.has(b.location))return res.status(400).json({error:'Invalid location'});if(b.status&&!allowedStatuses.has(b.status))return res.status(400).json({error:'Invalid status'});const fields=['name','type','deal','location','price','area','rooms','status','publication_status','description'];const sets=[],vals=[];for(const f of fields)if(b[f]!==undefined){sets.push(`${f}=?`);vals.push(f==='rooms'?Number(b[f]):b[f])}if(!sets.length)return res.json(p);sets.push('updated_at=?');vals.push(now(),req.params.id);db.prepare(`UPDATE properties SET ${sets.join(',')} WHERE id=?`).run(...vals);res.json(db.prepare('SELECT * FROM properties WHERE id=?').get(req.params.id));});
app.patch('/api/admin/properties/:id/status',auth,(req,res)=>{const {status}=req.body||{};if(!allowedStatuses.has(status))return res.status(400).json({error:'Invalid status'});const t=now();const r=db.prepare('UPDATE properties SET status=?,updated_at=? WHERE id=?').run(status,t,req.params.id);if(!r.changes)return res.status(404).json({error:'Not found'});res.json(db.prepare('SELECT * FROM properties WHERE id=?').get(req.params.id));});
app.patch('/api/admin/properties/:id/publication',auth,(req,res)=>{const {publication_status}=req.body||{};if(!['draft','published','unpublished'].includes(publication_status))return res.status(400).json({error:'Invalid publication status'});const r=db.prepare('UPDATE properties SET publication_status=?,updated_at=? WHERE id=?').run(publication_status,now(),req.params.id);if(!r.changes)return res.status(404).json({error:'Not found'});res.json(db.prepare('SELECT * FROM properties WHERE id=?').get(req.params.id));});
app.get('/api/admin/requests',auth,(req,res)=>res.json(db.prepare('SELECT id,code,type,status,user_name,user_phone,payload,created_at,updated_at FROM requests ORDER BY id DESC').all()));
app.patch('/api/admin/requests/:id',auth,(req,res)=>{const {status}=req.body||{};if(!allowedRequestStatuses.has(status))return res.status(400).json({error:'Invalid status'});const r=db.prepare('UPDATE requests SET status=?,updated_at=? WHERE id=?').run(status,now(),req.params.id);if(!r.changes)return res.status(404).json({error:'Not found'});res.json({ok:true});});
app.get('/api/admin/stats',auth,(req,res)=>{const count=s=>db.prepare('SELECT COUNT(*) c FROM properties WHERE status=?').get(s).c;res.json({total:db.prepare('SELECT COUNT(*) c FROM properties').get().c,available:count('available'),for_rent:count('for_rent'),paused:count('paused'),closed_sold:count('closed_sold'),closed_rented:count('closed_rented'),requests:db.prepare('SELECT COUNT(*) c FROM requests').get().c,views:db.prepare('SELECT COALESCE(SUM(views),0) n FROM properties').get().n,favorites:db.prepare('SELECT COALESCE(SUM(favorites_count),0) n FROM properties').get().n,contacts:db.prepare('SELECT COALESCE(SUM(contacts),0) n FROM properties').get().n});});

const port=Number(env.PORT||8080);app.listen(port,()=>console.log(`Jableh API listening on ${port}`));
