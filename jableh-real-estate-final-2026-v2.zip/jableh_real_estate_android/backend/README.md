# عقارات جبلة — Backend

REST API production-ready baseline with SQLite, JWT admin authentication, rate limiting, Helmet and Docker.

## Local
1. Copy `.env.example` to `.env` and set `JWT_SECRET` and `ADMIN_PASSWORD`.
2. `npm install`
3. `npm start`
4. Health: `GET http://localhost:8080/health`

## Production
Run behind HTTPS using a managed host/reverse proxy. Set a strong JWT_SECRET and admin password. For multi-instance deployments, migrate SQLite to PostgreSQL before scaling horizontally.
