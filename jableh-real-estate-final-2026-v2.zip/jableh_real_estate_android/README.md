# عقارات جبلة

مشروع Android + Backend لتطبيق «عقارات جبلة» لمدينة جبلة وريف جبلة.

## الحالة
هذه حزمة مصدر قابلة للبناء. تم التحقق محليًا من بنية ملفات Android ومن صحة JavaScript/Node syntax، لكن لم يتم تنفيذ Gradle/Android SDK داخل بيئة العمل الحالية لأن Android SDK وGradle غير مثبتين فيها.

## المكونات
- Android WebView client: `app/`
- Node.js API: `backend/`
- Docker: `docker-compose.yml`
- CI build: `.github/workflows/android-release.yml`
- التشغيل والنشر: `DEPLOYMENT.md`

## مهم
`config.js` يحتاج عنوان HTTPS الحقيقي لخادم API قبل إصدار النسخة الإنتاجية.
لا تستخدم بيانات الإدارة التطويرية في الإنتاج.
