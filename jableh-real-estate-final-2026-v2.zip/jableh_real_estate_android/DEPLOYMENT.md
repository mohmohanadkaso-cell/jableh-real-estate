# عقارات جبلة — الحزمة النهائية للتشغيل

## ما تم تجهيزه
- تطبيق Android باسم «عقارات جبلة».
- RTL عربي وواجهة المستخدم الأساسية.
- البحث حسب البيع/الإيجار، النوع، الموقع، والغرف.
- المواقع المسموحة: كل جبلة، مدينة جبلة، ريف جبلة، والمنطقة المحددة على الخريطة.
- المفضلة و«طلباتي» محليًا على الجهاز.
- «أريد عقارًا»، «اعرض عقارك معنا»، «تواصل مع عقارات جبلة»، و«طلب معاينة» ترسل إلى API عند ربط الخادم.
- إدارة العقارات وحالاتها: متاح، للإيجار، متوقف مؤقتًا، مغلق بعد البيع، مغلق بعد التأجير.
- لا يوجد نظام حجز أو حجز مؤقت.
- صاحب العقار لا ينشر مباشرة؛ الإدارة تراجع الطلب ثم تنشئ وتنشر العقار.
- المشترون/المستأجرون يتواصلون مع «عقارات جبلة» فقط.
- قاعدة بيانات SQLite + API Node.js/Express + JWT + bcrypt + Helmet + rate limiting.
- Docker وGitHub Actions لبناء Android.

## 1) تشغيل الخادم
انسخ `.env.production.example` إلى `.env` وعدّل القيم السرية، ثم:

```bash
docker compose up -d --build
```

اختبر:

```bash
curl http://localhost:8080/health
```

في الإنتاج يجب وضع API خلف HTTPS وعدم استخدام بيانات الإدارة الافتراضية.

## 2) ربط تطبيق Android بالخادم
افتح:

`app/src/main/assets/config.js`

واجعل:

```js
window.JABLEH_API_BASE = 'https://YOUR-API-DOMAIN.example';
```

يجب أن يكون العنوان HTTPS لأن التطبيق يمنع cleartext HTTP.

## 3) بناء Android
المشروع مضبوط على `compileSdk 36` و`targetSdk 36`.

بيئة هذا المشروع تحتوي على GitHub Actions تستخدم Android SDK 36 وGradle 8.10.2. يمكن تشغيل البناء من GitHub بعد رفع المستودع وتشغيل workflow:

`Build Android release`

الناتج:

`app/build/outputs/bundle/release/app-release.aab`

## 4) توقيع Google Play
اترك مفتاح الرفع الخاص بك تحت سيطرتك. لا تضع ملف `.jks` داخل المستودع.

في Google Play استخدم Play App Signing، وأنشئ Upload Key كما تطلب Google، ثم استخدمه لتوقيع الـAAB قبل رفعه.

## 5) تحديثات التطبيق
كل تحديث يجب أن يرفع `versionCode` في `app/build.gradle` إلى رقم أعلى من الإصدار السابق.
