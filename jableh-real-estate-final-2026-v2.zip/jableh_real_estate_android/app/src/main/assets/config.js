/* Production configuration for عقارات جبلة.
 * Set this to your HTTPS API origin before production release.
 * Example: https://api.example.com
 */
window.JABLEH_API_BASE = '';
