# بناء نسخة Android — عقارات جبلة

## متطلبات البناء
- JDK 17
- Android SDK Platform 36
- Android Build Tools 36.0.0
- Gradle 8.10.2 أو أحدث متوافق مع Android Gradle Plugin المستخدم

## بناء AAB
من جذر المشروع:

```bash
gradle bundleRelease --no-daemon
```

الناتج المتوقع:

`app/build/outputs/bundle/release/app-release.aab`

## مهم: التوقيع
النسخة الحالية لا تحتوي مفتاح توقيعك. لا تضع `.jks` داخل Git.
للنشر، استخدم Upload Key الخاص بك مع Play App Signing في Google Play Console.

## قبل البناء الإنتاجي
1. ضع عنوان API حقيقيًا عبر `app/src/main/assets/config.js` ويجب أن يكون HTTPS.
2. غيّر `versionCode` إلى رقم أعلى عند كل تحديث.
3. راجع `versionName`.
4. أنشئ AAB موقّعًا بمفتاح الرفع الخاص بك.
5. اختبر تسجيل الإدارة والطلبات وتغيير حالة العقار على الخادم الحقيقي.
